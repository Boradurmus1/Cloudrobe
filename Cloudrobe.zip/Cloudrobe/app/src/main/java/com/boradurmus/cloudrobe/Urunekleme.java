package com.boradurmus.cloudrobe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Urunekleme extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urunekleme);
    }
}